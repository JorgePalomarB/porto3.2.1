<?php

namespace Mageplaza\LayeredNavigation\Model\Search;

use Magento\Framework\Api\Search\FilterGroup as SourceFilterGroup;

/**
 * Groups two or more filters together using a logical OR
 */
class FilterGroup extends SourceFilterGroup
{
}
